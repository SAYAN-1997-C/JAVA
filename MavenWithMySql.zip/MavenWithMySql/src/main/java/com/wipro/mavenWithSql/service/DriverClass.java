package com.wipro.mavenWithSql.service;

import java.io.File;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.mavenWithSql.bean.User;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory factory = new Configuration()
								.configure()
								.addAnnotatedClass(User.class)
								.buildSessionFactory();
		Session session = null;
		Transaction tx = null;
		try {
			session = factory.openSession();
			User user = new User("Sayan Jashu", "West Bengal");
			tx = session.beginTransaction();
			session.save(user);
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error ocuured in Insert data");
			e.printStackTrace();
		} finally {
			factory.close();
		}
	}

}
